import sys
import fibo
import builtins

abc = 123
_abc = 321

print('dir:', dir())
print('dir-fobo', dir(fibo))
print('dir-buildin:', dir(builtins))
