# 当执行 python3 module 时，会执行该文件
import fibo

print('main 入口文件')

print(fibo.fib2(888))
