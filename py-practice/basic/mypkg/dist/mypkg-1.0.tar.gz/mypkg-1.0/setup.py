from distutils.core import setup

setup(name='mypkg',
      version='1.0',
      author='x3927',
      author_email='3927@gmail.com',
      url='http://xxx.com/mypkg',
      packages=['mypkg', 'mypkg.utils'],
      )
